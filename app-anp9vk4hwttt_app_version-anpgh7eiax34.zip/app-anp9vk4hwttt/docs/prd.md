# Requirements Document

## 1. Application Overview
- **Application Name:** SalonBook
- **Description:** A salon booking website that allows salon owners to register their salon, add services with pricing details, and enables customers to browse and book appointments online.

---

## 2. Users & Use Cases

### Target Users
- **Salon Owners:** Register their salon, manage service listings and pricing.
- **Customers:** Browse salons, view services and prices, book appointments.

### Core Use Cases
- A salon owner registers their salon and adds services with prices.
- A customer visits the site, browses available services, and books an appointment.

---

## 3. Page Structure & Core Features

### Page Overview
```
SalonBook
├── Home Page
├── Salon Listing Page
├── Salon Detail & Booking Page
├── Customer Booking Confirmation Page
├── Owner Registration & Login Page
└── Owner Dashboard
    ├── Salon Profile Management
    ├── Service & Pricing Management
    └── Booking Management
```

### 3.1 Home Page
- Hero section with a brief platform introduction and a call-to-action to browse salons or register as an owner.
- Navigation links to: Browse Salons, Owner Login / Register.

### 3.2 Salon Listing Page
- Displays a list of all registered salons.
- Each salon card shows: salon name, brief description, and a link to the salon detail page.
- No login required for customers to browse.

### 3.3 Salon Detail & Booking Page
- Displays salon profile: name, description, contact details, address.
- Lists all services offered by the salon, each with:
  - Service name
  - Description (optional)
  - Price
  - Duration
- Booking form:
  - Customer name
  - Customer contact (phone or email)
  - Select service
  - Select preferred date and time
  - Submit booking button
- No customer account required to book.

### 3.4 Customer Booking Confirmation Page
- Displays a confirmation summary after a booking is submitted:
  - Salon name
  - Selected service, date, and time
  - Customer name and contact
- Confirmation message indicating the booking has been received.

### 3.5 Owner Registration & Login Page
- **Registration form fields:**
  - Owner full name
  - Email address
  - Password
  - Salon name
  - Salon address
  - Salon contact number
  - Brief salon description
- **Login form:** Email and password.
- After registration and login, owner is redirected to the Owner Dashboard.

### 3.6 Owner Dashboard

#### 3.6.1 Salon Profile Management
- Owner can view and edit salon details: name, address, contact number, description.

#### 3.6.2 Service & Pricing Management
- Owner can add a new service:
  - Service name
  - Description (optional)
  - Price
  - Duration
- Owner can edit or delete existing services.
- Services are displayed in a list/table format.

#### 3.6.3 Booking Management
- Owner can view all incoming bookings for their salon.
- Each booking entry shows: customer name, contact, selected service, date, and time.
- Owner can mark a booking as Confirmed or Cancelled.

---

## 4. Business Rules & Logic

- A salon owner must complete registration before accessing the dashboard or adding services.
- Each salon owner manages only their own salon profile and bookings.
- Customers do not need to create an account to book an appointment.
- A booking is created with a default status of Pending until the owner confirms or cancels it.
- Each service must have at minimum a name and a price to be saved.
- Available booking time slots are based on the date and time selected by the customer; no automated conflict detection is required in this version.

---

## 5. Exceptions & Edge Cases

| Scenario | Handling |
|---|---|
| Owner submits registration with an already-registered email | Display error: this email is already registered |
| Owner login with incorrect credentials | Display error: invalid email or password |
| Customer submits booking form with missing required fields | Highlight missing fields and prevent submission |
| Owner attempts to delete a service that has pending bookings | Allow deletion; existing bookings remain in the system |
| No salons registered yet | Salon listing page displays a message: no salons available yet |
| Owner has no services added | Salon detail page shows a message: no services listed yet |

---

## 6. Acceptance Criteria

- A salon owner can successfully register, log in, and access the dashboard.
- An owner can add, edit, and delete services with name, price, and duration.
- A customer can browse the salon listing without logging in.
- A customer can view a salon's services and prices on the salon detail page.
- A customer can submit a booking and receive a confirmation page.
- An owner can view all bookings and update their status to Confirmed or Cancelled.
- All form validations are enforced on required fields.

---

## 7. Out of Scope (This Version)

- Multiple salon owners on a marketplace platform (this version supports a single salon per owner account).
- Customer account registration, login, or booking history.
- Staff member management or staff-specific booking.
- Automated time slot conflict detection or calendar availability management.
- Payment processing or online payment integration.
- Email or SMS notifications for booking confirmations.
- Search or filter functionality on the salon listing page.
- Mobile app version.