import { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { createSalon } from '@/db/api';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';

interface LoginFormData {
  email: string;
  password: string;
}

interface RegisterFormData {
  full_name: string;
  email: string;
  password: string;
  salon_name: string;
  salon_address: string;
  salon_contact: string;
  salon_description: string;
}

export default function OwnerAuthPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signInWithEmail, signUpWithEmail } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  const loginForm = useForm<LoginFormData>({
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const registerForm = useForm<RegisterFormData>({
    defaultValues: {
      full_name: '',
      email: '',
      password: '',
      salon_name: '',
      salon_address: '',
      salon_contact: '',
      salon_description: '',
    },
  });

  const onLogin = async (data: LoginFormData) => {
    setIsLoggingIn(true);
    const { error } = await signInWithEmail(data.email, data.password);
    setIsLoggingIn(false);

    if (error) {
      toast.error(error.message || 'Invalid email or password');
    } else {
      toast.success('Logged in successfully!');
      const from = (location.state as any)?.from || '/dashboard';
      navigate(from);
    }
  };

  const onRegister = async (data: RegisterFormData) => {
    setIsRegistering(true);

    // First, create the auth account
    const { error: authError } = await signUpWithEmail(data.email, data.password, data.full_name);

    if (authError) {
      setIsRegistering(false);
      if (authError.message.includes('already registered')) {
        toast.error('This email is already registered');
      } else {
        toast.error(authError.message || 'Registration failed');
      }
      return;
    }

    // Wait a moment for the profile to be created by the trigger
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Then create the salon (the user should be logged in now)
    const salon = await createSalon({
      owner_id: '', // Will be set by RLS policy using auth.uid()
      name: data.salon_name,
      address: data.salon_address,
      contact_number: data.salon_contact,
      description: data.salon_description || null,
    });

    setIsRegistering(false);

    if (salon) {
      toast.success('Registration successful! Welcome to SalonBook.');
      navigate('/dashboard');
    } else {
      toast.error('Account created but salon setup failed. Please complete setup in dashboard.');
      navigate('/dashboard');
    }
  };

  return (
    <MainLayout>
      <div className="container py-12 px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Salon Owner Portal</h1>
            <p className="text-muted-foreground">
              Sign in to manage your salon or register to get started
            </p>
          </div>

          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Sign In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Sign In</CardTitle>
                  <CardDescription>Enter your credentials to access your dashboard</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="email"
                        rules={{
                          required: 'Email is required',
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: 'Invalid email address',
                          },
                        }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="owner@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={loginForm.control}
                        name="password"
                        rules={{ required: 'Password is required' }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="••••••••" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button type="submit" className="w-full" disabled={isLoggingIn}>
                        {isLoggingIn ? 'Signing In...' : 'Sign In'}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Register Your Salon</CardTitle>
                  <CardDescription>Create an account and list your salon</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="full_name"
                        rules={{ required: 'Full name is required' }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="email"
                        rules={{
                          required: 'Email is required',
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: 'Invalid email address',
                          },
                        }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="owner@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="password"
                        rules={{
                          required: 'Password is required',
                          minLength: {
                            value: 6,
                            message: 'Password must be at least 6 characters',
                          },
                        }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="••••••••" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="border-t pt-4 mt-4">
                        <h3 className="font-semibold mb-3">Salon Information</h3>

                        <div className="space-y-4">
                          <FormField
                            control={registerForm.control}
                            name="salon_name"
                            rules={{ required: 'Salon name is required' }}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Salon Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Beautiful Hair Salon" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={registerForm.control}
                            name="salon_address"
                            rules={{ required: 'Address is required' }}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Salon Address</FormLabel>
                                <FormControl>
                                  <Input placeholder="123 Main St, City, State" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={registerForm.control}
                            name="salon_contact"
                            rules={{ required: 'Contact number is required' }}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contact Number</FormLabel>
                                <FormControl>
                                  <Input placeholder="+1 (555) 123-4567" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={registerForm.control}
                            name="salon_description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Brief Description (Optional)</FormLabel>
                                <FormControl>
                                  <Textarea
                                    placeholder="Tell customers about your salon..."
                                    className="resize-none"
                                    rows={3}
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <Button type="submit" className="w-full" disabled={isRegistering}>
                        {isRegistering ? 'Creating Account...' : 'Register Salon'}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
}
