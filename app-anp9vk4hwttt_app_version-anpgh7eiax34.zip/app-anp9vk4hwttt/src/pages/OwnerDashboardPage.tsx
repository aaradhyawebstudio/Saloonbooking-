import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { getSalonByOwnerId, updateSalon, createSalon } from '@/db/api';
import type { Salon } from '@/types/types';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';

interface SalonFormData {
  name: string;
  address: string;
  contact_number: string;
  description: string;
}

export default function OwnerDashboardPage() {
  const { user } = useAuth();
  const [salon, setSalon] = useState<Salon | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<SalonFormData>({
    defaultValues: {
      name: '',
      address: '',
      contact_number: '',
      description: '',
    },
  });

  useEffect(() => {
    if (user) {
      loadSalon();
    }
  }, [user]);

  const loadSalon = async () => {
    if (!user) return;
    setLoading(true);
    const data = await getSalonByOwnerId(user.id);
    setSalon(data);
    if (data) {
      form.reset({
        name: data.name,
        address: data.address,
        contact_number: data.contact_number,
        description: data.description || '',
      });
    }
    setLoading(false);
  };

  const onSubmit = async (data: SalonFormData) => {
    if (!user) return;

    setSaving(true);

    if (salon) {
      // Update existing salon
      const updated = await updateSalon(salon.id, {
        name: data.name,
        address: data.address,
        contact_number: data.contact_number,
        description: data.description || null,
      });

      if (updated) {
        setSalon(updated);
        toast.success('Salon profile updated successfully!');
      } else {
        toast.error('Failed to update salon profile');
      }
    } else {
      // Create new salon
      const created = await createSalon({
        owner_id: user.id,
        name: data.name,
        address: data.address,
        contact_number: data.contact_number,
        description: data.description || null,
      });

      if (created) {
        setSalon(created);
        toast.success('Salon profile created successfully!');
      } else {
        toast.error('Failed to create salon profile');
      }
    }

    setSaving(false);
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-64 bg-muted" />
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 bg-muted" />
              <Skeleton className="h-4 w-full bg-muted" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full bg-muted" />
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Salon Profile</h1>
          <p className="text-muted-foreground">
            {salon ? 'Manage your salon information' : 'Set up your salon profile'}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{salon ? 'Edit Salon Details' : 'Create Salon Profile'}</CardTitle>
            <CardDescription>
              This information will be visible to customers browsing salons
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  rules={{ required: 'Salon name is required' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Salon Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Beautiful Hair Salon" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  rules={{ required: 'Address is required' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input placeholder="123 Main St, City, State" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contact_number"
                  rules={{ required: 'Contact number is required' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Number</FormLabel>
                      <FormControl>
                        <Input placeholder="+1 (555) 123-4567" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell customers about your salon..."
                          className="resize-none"
                          rows={4}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" disabled={saving}>
                  {saving ? 'Saving...' : salon ? 'Update Profile' : 'Create Profile'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
