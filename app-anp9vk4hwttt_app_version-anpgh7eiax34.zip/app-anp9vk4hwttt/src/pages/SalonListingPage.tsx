import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { getAllSalons } from '@/db/api';
import type { Salon } from '@/types/types';
import { MapPin, Phone } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function SalonListingPage() {
  const [salons, setSalons] = useState<Salon[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSalons();
  }, []);

  const loadSalons = async () => {
    setLoading(true);
    const data = await getAllSalons();
    setSalons(data);
    setLoading(false);
  };

  return (
    <MainLayout>
      <div className="container py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Browse Salons</h1>
            <p className="text-muted-foreground">
              Discover the perfect salon for your beauty needs
            </p>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                    <Skeleton className="h-4 w-full bg-muted" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-full mb-2 bg-muted" />
                    <Skeleton className="h-4 w-2/3 bg-muted" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : salons.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-muted-foreground mb-4">No salons available yet</p>
                <Button asChild>
                  <Link to="/register">Be the First to Register</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {salons.map((salon) => (
                <Card key={salon.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>{salon.name}</CardTitle>
                    <CardDescription className="line-clamp-2">
                      {salon.description || 'Professional salon services'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start space-x-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                      <span className="text-muted-foreground">{salon.address}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground shrink-0" />
                      <span className="text-muted-foreground">{salon.contact_number}</span>
                    </div>
                    <Button className="w-full mt-2" asChild>
                      <Link to={`/salons/${salon.id}`}>View Details & Book</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
