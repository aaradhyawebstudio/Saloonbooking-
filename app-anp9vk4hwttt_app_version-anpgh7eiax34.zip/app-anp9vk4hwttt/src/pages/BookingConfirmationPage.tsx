import { useLocation, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, MapPin, Phone, Calendar, Clock } from 'lucide-react';
import type { Booking, Salon } from '@/types/types';

export default function BookingConfirmationPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { booking, salon } = (location.state || {}) as { booking?: Booking; salon?: Salon };

  if (!booking || !salon) {
    return (
      <MainLayout>
        <div className="container py-12 px-4">
          <Card className="max-w-2xl mx-auto text-center py-12">
            <CardContent>
              <p className="text-muted-foreground mb-4">No booking information found</p>
              <Button onClick={() => navigate('/salons')}>Browse Salons</Button>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container py-12 px-4">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Success Message */}
          <Card className="border-primary/50 bg-primary/5">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-10 w-10 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold mb-2">Booking Confirmed!</h1>
                  <p className="text-muted-foreground">
                    Your appointment request has been received. The salon will contact you shortly to confirm.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Booking Details */}
          <Card>
            <CardHeader>
              <CardTitle>Booking Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Salon Information</h3>
                <div className="space-y-2 text-sm">
                  <p className="font-medium text-lg">{salon.name}</p>
                  <div className="flex items-start space-x-2">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{salon.address}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="text-muted-foreground">{salon.contact_number}</span>
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-2">Your Information</h3>
                <div className="space-y-1 text-sm">
                  <p>
                    <span className="text-muted-foreground">Name:</span>{' '}
                    <span className="font-medium">{booking.customer_name}</span>
                  </p>
                  <p>
                    <span className="text-muted-foreground">Contact:</span>{' '}
                    <span className="font-medium">{booking.customer_contact}</span>
                  </p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-2">Appointment</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="font-medium">
                      {new Date(booking.booking_date).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="font-medium">{booking.booking_time}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button onClick={() => navigate('/salons')} className="flex-1">
              Browse More Salons
            </Button>
            <Button onClick={() => navigate('/')} variant="outline" className="flex-1">
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
