import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getSalonById, createBooking } from '@/db/api';
import type { SalonWithServices, Service } from '@/types/types';
import { MapPin, Phone, Clock, DollarSign } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';

interface BookingFormData {
  customer_name: string;
  customer_contact: string;
  service_id: string;
  booking_date: string;
  booking_time: string;
}

export default function SalonDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [salon, setSalon] = useState<SalonWithServices | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<BookingFormData>({
    defaultValues: {
      customer_name: '',
      customer_contact: '',
      service_id: '',
      booking_date: '',
      booking_time: '',
    },
  });

  useEffect(() => {
    if (id) {
      loadSalon();
    }
  }, [id]);

  const loadSalon = async () => {
    if (!id) return;
    setLoading(true);
    const data = await getSalonById(id);
    setSalon(data);
    setLoading(false);
  };

  const onSubmit = async (data: BookingFormData) => {
    if (!salon) return;

    setSubmitting(true);
    const booking = await createBooking({
      salon_id: salon.id,
      service_id: data.service_id,
      customer_name: data.customer_name,
      customer_contact: data.customer_contact,
      booking_date: data.booking_date,
      booking_time: data.booking_time,
    });

    setSubmitting(false);

    if (booking) {
      toast.success('Booking submitted successfully!');
      navigate('/booking-confirmation', { state: { booking, salon } });
    } else {
      toast.error('Failed to create booking. Please try again.');
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container py-12 px-4">
          <div className="max-w-4xl mx-auto space-y-6">
            <Skeleton className="h-12 w-3/4 bg-muted" />
            <Skeleton className="h-32 w-full bg-muted" />
            <Skeleton className="h-64 w-full bg-muted" />
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!salon) {
    return (
      <MainLayout>
        <div className="container py-12 px-4">
          <Card className="max-w-2xl mx-auto text-center py-12">
            <CardContent>
              <p className="text-muted-foreground mb-4">Salon not found</p>
              <Button onClick={() => navigate('/salons')}>Back to Salons</Button>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  const services = salon.services || [];

  return (
    <MainLayout>
      <div className="container py-12 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Salon Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-3xl">{salon.name}</CardTitle>
              <CardDescription className="text-base">
                {salon.description || 'Professional salon services'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
                <span>{salon.address}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-muted-foreground shrink-0" />
                <span>{salon.contact_number}</span>
              </div>
            </CardContent>
          </Card>

          {/* Services */}
          <div>
            <h2 className="text-2xl font-bold mb-4">Our Services</h2>
            {services.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  No services listed yet
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {services.map((service) => (
                  <Card key={service.id}>
                    <CardHeader>
                      <CardTitle className="text-lg">{service.name}</CardTitle>
                      {service.description && (
                        <CardDescription>{service.description}</CardDescription>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span className="font-semibold">${service.price.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{service.duration_minutes} minutes</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Booking Form */}
          {services.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Book an Appointment</CardTitle>
                <CardDescription>Fill in your details to book a service</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="customer_name"
                      rules={{ required: 'Name is required' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="customer_contact"
                      rules={{ required: 'Contact is required' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Contact (Phone or Email)</FormLabel>
                          <FormControl>
                            <Input placeholder="phone@example.com or +1234567890" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="service_id"
                      rules={{ required: 'Please select a service' }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select Service</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Choose a service" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {services.map((service) => (
                                <SelectItem key={service.id} value={service.id}>
                                  {service.name} - ${service.price.toFixed(2)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="booking_date"
                        rules={{ required: 'Date is required' }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Date</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="booking_time"
                        rules={{ required: 'Time is required' }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Time</FormLabel>
                            <FormControl>
                              <Input type="time" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button type="submit" className="w-full" disabled={submitting}>
                      {submitting ? 'Submitting...' : 'Book Appointment'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
