import HomePage from './pages/HomePage';
import SalonListingPage from './pages/SalonListingPage';
import SalonDetailPage from './pages/SalonDetailPage';
import BookingConfirmationPage from './pages/BookingConfirmationPage';
import OwnerAuthPage from './pages/OwnerAuthPage';
import OwnerDashboardPage from './pages/OwnerDashboardPage';
import ServicesManagementPage from './pages/ServicesManagementPage';
import BookingsManagementPage from './pages/BookingsManagementPage';
import NotFound from './pages/NotFound';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <HomePage />,
  },
  {
    name: 'Browse Salons',
    path: '/salons',
    element: <SalonListingPage />,
  },
  {
    name: 'Salon Detail',
    path: '/salons/:id',
    element: <SalonDetailPage />,
  },
  {
    name: 'Booking Confirmation',
    path: '/booking-confirmation',
    element: <BookingConfirmationPage />,
  },
  {
    name: 'Sign In',
    path: '/login',
    element: <OwnerAuthPage />,
  },
  {
    name: 'Register',
    path: '/register',
    element: <OwnerAuthPage />,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <OwnerDashboardPage />,
  },
  {
    name: 'Services Management',
    path: '/dashboard/services',
    element: <ServicesManagementPage />,
  },
  {
    name: 'Bookings Management',
    path: '/dashboard/bookings',
    element: <BookingsManagementPage />,
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFound />,
  },
];

export default routes;
