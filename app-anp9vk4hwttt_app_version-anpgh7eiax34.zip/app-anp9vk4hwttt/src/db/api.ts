import { supabase } from './supabase';
import type { Salon, Service, Booking, BookingStatus, SalonWithServices, BookingWithDetails } from '@/types/types';

// Salon API
export async function getAllSalons(): Promise<Salon[]> {
  const { data, error } = await supabase
    .from('salons')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching salons:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function getSalonById(id: string): Promise<SalonWithServices | null> {
  const { data, error } = await supabase
    .from('salons')
    .select('*, services(*)')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Error fetching salon:', error);
    return null;
  }
  return data;
}

export async function getSalonByOwnerId(ownerId: string): Promise<Salon | null> {
  const { data, error } = await supabase
    .from('salons')
    .select('*')
    .eq('owner_id', ownerId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching salon by owner:', error);
    return null;
  }
  return data;
}

export async function createSalon(salon: Omit<Salon, 'id' | 'created_at' | 'updated_at'>): Promise<Salon | null> {
  const { data, error } = await supabase
    .from('salons')
    .insert(salon)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating salon:', error);
    return null;
  }
  return data;
}

export async function updateSalon(id: string, updates: Partial<Salon>): Promise<Salon | null> {
  const { data, error } = await supabase
    .from('salons')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating salon:', error);
    return null;
  }
  return data;
}

// Service API
export async function getServicesBySalonId(salonId: string): Promise<Service[]> {
  const { data, error } = await supabase
    .from('services')
    .select('*')
    .eq('salon_id', salonId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching services:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function createService(service: Omit<Service, 'id' | 'created_at' | 'updated_at'>): Promise<Service | null> {
  const { data, error } = await supabase
    .from('services')
    .insert(service)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating service:', error);
    return null;
  }
  return data;
}

export async function updateService(id: string, updates: Partial<Service>): Promise<Service | null> {
  const { data, error } = await supabase
    .from('services')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating service:', error);
    return null;
  }
  return data;
}

export async function deleteService(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('services')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting service:', error);
    return false;
  }
  return true;
}

// Booking API
export async function createBooking(booking: Omit<Booking, 'id' | 'status' | 'created_at' | 'updated_at'>): Promise<Booking | null> {
  const { data, error } = await supabase
    .from('bookings')
    .insert(booking)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating booking:', error);
    return null;
  }
  return data;
}

export async function getBookingsBySalonId(salonId: string): Promise<BookingWithDetails[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select('*, service:services(*), salon:salons(*)')
    .eq('salon_id', salonId)
    .order('booking_date', { ascending: false })
    .order('booking_time', { ascending: false });

  if (error) {
    console.error('Error fetching bookings:', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function updateBookingStatus(id: string, status: BookingStatus): Promise<Booking | null> {
  const { data, error } = await supabase
    .from('bookings')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating booking status:', error);
    return null;
  }
  return data;
}
