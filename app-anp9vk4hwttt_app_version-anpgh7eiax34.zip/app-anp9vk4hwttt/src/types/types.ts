export interface Profile {
  id: string;
  email: string | null;
  full_name: string;
  phone: string | null;
  created_at: string;
}

export interface Salon {
  id: string;
  owner_id: string;
  name: string;
  description: string | null;
  address: string;
  contact_number: string;
  created_at: string;
  updated_at: string;
}

export interface Service {
  id: string;
  salon_id: string;
  name: string;
  description: string | null;
  price: number;
  duration_minutes: number;
  created_at: string;
  updated_at: string;
}

export type BookingStatus = 'pending' | 'confirmed' | 'cancelled';

export interface Booking {
  id: string;
  salon_id: string;
  service_id: string;
  customer_name: string;
  customer_contact: string;
  booking_date: string;
  booking_time: string;
  status: BookingStatus;
  created_at: string;
  updated_at: string;
}

export interface BookingWithDetails extends Booking {
  service?: Service;
  salon?: Salon;
}

export interface SalonWithServices extends Salon {
  services?: Service[];
}
