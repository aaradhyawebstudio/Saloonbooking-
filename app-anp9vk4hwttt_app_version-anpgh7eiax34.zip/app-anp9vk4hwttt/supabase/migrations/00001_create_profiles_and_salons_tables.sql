-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text NOT NULL,
  phone text,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id);

-- Create salons table
CREATE TABLE salons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  address text NOT NULL,
  contact_number text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE salons ENABLE ROW LEVEL SECURITY;

-- Salons policies
CREATE POLICY "Anyone can view salons" ON salons
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Owners can insert their own salon" ON salons
  FOR INSERT TO authenticated 
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners can update their own salon" ON salons
  FOR UPDATE TO authenticated 
  USING (auth.uid() = owner_id);

CREATE POLICY "Owners can delete their own salon" ON salons
  FOR DELETE TO authenticated 
  USING (auth.uid() = owner_id);

-- Create services table
CREATE TABLE services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  price numeric(10, 2) NOT NULL CHECK (price >= 0),
  duration_minutes integer NOT NULL CHECK (duration_minutes > 0),
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE services ENABLE ROW LEVEL SECURITY;

-- Services policies
CREATE POLICY "Anyone can view services" ON services
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Salon owners can insert services" ON services
  FOR INSERT TO authenticated 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM salons 
      WHERE salons.id = services.salon_id 
      AND salons.owner_id = auth.uid()
    )
  );

CREATE POLICY "Salon owners can update their services" ON services
  FOR UPDATE TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM salons 
      WHERE salons.id = services.salon_id 
      AND salons.owner_id = auth.uid()
    )
  );

CREATE POLICY "Salon owners can delete their services" ON services
  FOR DELETE TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM salons 
      WHERE salons.id = services.salon_id 
      AND salons.owner_id = auth.uid()
    )
  );

-- Create booking status enum
CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'cancelled');

-- Create bookings table
CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  customer_name text NOT NULL,
  customer_contact text NOT NULL,
  booking_date date NOT NULL,
  booking_time time NOT NULL,
  status booking_status DEFAULT 'pending' NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Bookings policies
CREATE POLICY "Anyone can create bookings" ON bookings
  FOR INSERT TO anon, authenticated 
  WITH CHECK (true);

CREATE POLICY "Salon owners can view their bookings" ON bookings
  FOR SELECT TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM salons 
      WHERE salons.id = bookings.salon_id 
      AND salons.owner_id = auth.uid()
    )
  );

CREATE POLICY "Salon owners can update their bookings" ON bookings
  FOR UPDATE TO authenticated 
  USING (
    EXISTS (
      SELECT 1 FROM salons 
      WHERE salons.id = bookings.salon_id 
      AND salons.owner_id = auth.uid()
    )
  );

-- Create trigger function to sync auth.users to profiles
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User')
  );
  RETURN NEW;
END;
$$;

-- Create trigger
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();